ouvrirFichier()
{
./main.sh
}


yad --title="caracteristiques pydf" --text-align=center --width="800" --height="200" --button="Annuler":1 \
 --text-info --back=white --fore=orange < help.txt 
ouvrirFichier

