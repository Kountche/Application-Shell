ouvrirFichier()
{
./main.sh
}


yad --title="erreur de commande"  --width="400" --height="200" --button="Annuler":1\
 --text-info --wrap --back=black --fore=red --justify=fill < erreur.txt
ouvrirFichier

